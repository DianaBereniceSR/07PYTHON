from django.contrib import admin
from .models import autor, categoria, archivo 

admin.site.register(autor)
admin.site.register(categoria)
admin.site.register(archivo) 

# Register your models here.
