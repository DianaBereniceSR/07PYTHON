from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Software)
admin.site.register(Departamento)
admin.site.register(Software_Departamento)
