from django.apps import AppConfig


class MascotaConfig(AppConfig):
    name = 'mascota'
