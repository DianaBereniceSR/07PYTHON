from django.contrib import admin
from .models import Gato

# Register your models here.

admin.site.register(Gato)