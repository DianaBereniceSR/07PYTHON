from django.contrib import admin
from django.urls import path
from django.conf.urls import *

from perdidos import views
app_name="lost"

urlpatterns = [
	#url(r'^media/(?P<path>.*")$', 'django.views.static.serve',{"document_root":settings.MEDIA_ROOT}),
	path('create/',views.Create.as_view(), name="create_view"),
	#path('autenticar/',views.valid, name="validar_view"),
	path('index/',views.Categorias.as_view(),name="categorias_view"),
	path('index/listado/<int:id>',views.listado,name="list_view"),
	path('index/details/<int:pk>',views.details.as_view(),name="details_view"),
    path('update/<int:pk>', views.update.as_view(), name="update_view"),
    path('delete/<int:pk>', views.delete.as_view(), name="delete_view"),
    path('',views.login.as_view(), name="login_view"),
    path('registro/',views.registro.as_view(), name="registro_view"),
]