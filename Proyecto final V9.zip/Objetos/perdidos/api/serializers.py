from rest_framework import serializers
from perdidos.models import Categoria, objetos

class CategoriaModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Categoria
        fields =[
            "id",
            "categoria",
        ]


class ObjetoModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = objetos
        fields =[
            "id",
            "nombre",
            "categoria",
            "talla",
            "color",
            "marca",
            "lugar_encontrado",
            "fecha_encontrado",
            "lugar_entrega",
            "estatus",
            "foto",
        ]
