from django.urls import path
from perdidos.api import views

app_name="api_objetos"

urlpatterns = [
    path('list_categorias/', views.ListCategoriaAPIView.as_view(), name ="listAPIView"),
    path('list_objetos/', views.ListObjetosAPIView.as_view(), name ="ObjetosAPIView"),
]